<!-- Page content -->
<div id="page-content">
    <!-- Page Header -->
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-book_open"></i>Selamat Datang di <strong>Career Center</strong><br><small>Fakultas Ekonomi dan Bisnis (FEB) Universitas Muhammadiyah Makassar</small>
            </h1>
        </div>
    </div>
    <!-- END Page Header -->
    <div class="row">
        <div class="col-md-6">
            <div class="block">
                <!-- Your Account Title -->
                <div class="block-title">
                    <h2><strong>INFORMASI / </strong> NEWS</h2>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="block">
                <!-- Your Account Title -->
                <div class="block-title">
                    <h2><strong>LOWONGAN KERJA / </strong> JOB VACANCY</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END Page Content -->